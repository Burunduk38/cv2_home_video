import cv2,os

# Загрузка каскада Хаара ДО цикла обработки видео
eye_cascade = cv2.CascadeClassifier("haarcascade_eye.xml")

if eye_cascade.empty():
  print("Ошибка: Не удалось загрузить каскад Хаара")
else:
  # Проверка размера файла каскада (в байтах)
  file_size = os.path.getsize("haarcascade_eye.xml")
  print("Размер файла каскада:", file_size, "байт")

def blur_eyes(frame):
  """
  Размывает область глаз на изображении.

  Args:
    frame: Кадр изображения (numpy array).

  Returns:
    Кадр с размытыми глазами.
  """
  # Преобразование кадра в grayscale
  gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

  # Обнаружение глаз
  # eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
  # eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3, minSize=(80, 40))
  eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.05, minNeighbors=3, minSize=(60, 30))

  # Нахождение области глаз
  # if eyes:
  if len(eyes) > 0:
    x_min = min(eye[0] for eye in eyes)
    y_min = min(eye[1] for eye in eyes)
    x_max = max(eye[0] + eye[2] for eye in eyes)
    y_max = max(eye[1] + eye[3] for eye in eyes)

    # Рисование прямоугольников вокруг обнаруженных глаз
    for (x, y, w, h) in eyes:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

    # Расширение области глаз
    x_min = max(0, int(round(x_min*0.9)))  # Ограничение по левому краю изображения
    # y_min = max(0, y_min - 10)  # Ограничение по верхнему краю изображения
    x_max = min(frame.shape[1], int(round(x_max*1.1)))  # Ограничение по правому краю
    # y_max = min(frame.shape[0], y_max + 10)  # Ограничение по нижнему краю

    # Рисование прямоугольника вокруг расширенной области глаз
    pt1_x = x_min
    pt1_y = y_min

    pt2_x = x_max
    pt2_y = y_max

    cv2.rectangle(frame, (pt1_x, pt1_y), (pt2_x, pt2_y), (255, 0, 0), 2)

    # Выделение области глаз на сером изображении
    eye_region_gray = gray[y_min:y_max, x_min:x_max]

    # Размытие области глаз в сером цвете
    blurred_region_gray = cv2.GaussianBlur(eye_region_gray, (49, 11), 7)

    # Преобразование серой области в цветную для совместимости вставки в цветной кадр
    blurred_region_color = cv2.cvtColor(blurred_region_gray, cv2.COLOR_GRAY2BGR)

    # Вставка размытой области обратно в цветной кадр
    frame[y_min:y_max, x_min:x_max] = blurred_region_color

  return frame  # Возврщаем кадр даже если глаз/глаза не найдены

# # Захват видеопотока
# cap = cv2.VideoCapture(0)

# Захват видеопотока
cap = cv2.VideoCapture(r'D:\ISZF\py_projects\OpenCV\My face.mp4')

while True:
  # Чтение кадра из видеопотока
  success, frame = cap.read()
  if not success:
    break

  # Размытие глаз
  frame = blur_eyes(frame)

  # Отображение кадра
  cv2.imshow("Video", frame)

  # Выход по нажатию клавиши 'q'
  if cv2.waitKey(1) & 0xFF == ord('q'):
    break

# Остановка захвата видео и закрытие окна
cap.release()
cv2.destroyAllWindows()
